class Note {
  int? id;
  String title;
  String content;
  int? categoryId; // Category ID to map to a category
  String createdAt;
  String updatedAt;
  bool isFavorite; // Add this field

  Note({
    this.id,
    required this.title,
    required this.content,
    this.categoryId,
    required this.createdAt,
    required this.updatedAt,
    this.isFavorite = false, // Default to false
  });

  // Getter to retrieve the category name based on categoryId
  String get category {
    switch (categoryId) {
      case 1:
        return 'Work';
      case 2:
        return 'Personal';
      case 3:
        return 'Ideas';
      case 4:
        return 'Other';
      default:
        return 'Unknown';
    }
  }

  // Update fromMap and toMap methods to include isFavorite and categoryId
  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      id: map['id'],
      title: map['title'],
      content: map['content'],
      categoryId: map['categoryId'],
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
      isFavorite: (map['isFavorite'] ?? 0) == 1, // Handle null and convert int to bool
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'categoryId': categoryId,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'isFavorite': isFavorite ? 1 : 0, // Convert bool to int
    };
  }

  // Updated copyWith method to use categoryId instead of category
 Note copyWith({
  int? id,
  String? title,
  String? content,
  int? categoryId,
  String? createdAt,
  String? updatedAt,
  bool? isFavorite,
}) {
  return Note(
    id: id ?? this.id,
    title: title ?? this.title,
    content: content ?? this.content,
    categoryId: categoryId ?? this.categoryId,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isFavorite: isFavorite ?? this.isFavorite,
  );
}
}