class Category {
  int? id;
  String name;

  Category({
    this.id,
    required this.name,
  });

  // Convert a Category object into a Map for database operations
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
    };
  }

  // Create a Category object from a Map (retrieved from the database)
  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['id'],
      name: map['name'],
    );
  }
}