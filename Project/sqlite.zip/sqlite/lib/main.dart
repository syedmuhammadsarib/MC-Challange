import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:intl/intl.dart';
import 'DatabaseHelper.dart';
import 'Note.dart';
import 'Category.dart';
import 'AddNoteScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final dbHelper = DatabaseHelper();

  await dbHelper.db;

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notes App',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: NotesApp(),
    );
  }
}

class NotesApp extends StatefulWidget {
  const NotesApp({super.key});

  @override
  _NotesAppState createState() => _NotesAppState();
}

class _NotesAppState extends State<NotesApp> with SingleTickerProviderStateMixin {
  List<Note> notes = [];
  List<Category> categories = [];
  int? selectedCategoryId;
  int _currentIndex = 0;
  bool _isDarkMode = false;
  late AnimationController _animationController;
  late Animation<double> _animation;

  String _searchQuery = '';

  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  final Map<String, Color> categoryColors = {
    'Work': Colors.blue.shade400,
    'Personal': Colors.green.shade400,
    'Ideas': Colors.orange.shade400,
    'Other': Colors.grey.shade400,
  };

  @override
  void initState() {
    super.initState();
    _fetchNotes();
    _fetchCategories();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    // Add a listener to the focus node
    _searchFocusNode.addListener(() {
      if (!_searchFocusNode.hasFocus) {
        // If the search bar loses focus, clear the search and return to the home page
        setState(() {
          _searchController.clear();
          _searchQuery = '';
        });
      }
    });
  }

  @override
  void dispose() {
    _searchFocusNode.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
      if (_isDarkMode) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  Future<void> _fetchNotes() async {
    final dbHelper = DatabaseHelper();
    List<Map<String, dynamic>> noteMaps = await dbHelper.getNotes(
      categoryId: selectedCategoryId,
    );

    setState(() {
      notes = noteMaps.map((noteMap) => Note.fromMap(noteMap)).toList();
    });
  }

  Future<void> _fetchCategories() async {
    final dbHelper = DatabaseHelper();
    List<Map<String, dynamic>> categoryMaps = await dbHelper.getCategories();

    setState(() {
      categories = categoryMaps.map((categoryMap) => Category.fromMap(categoryMap)).toList();
    });
  }

  Future<void> _deleteNote(int noteId) async {
    final dbHelper = DatabaseHelper();
    await dbHelper.deleteNote(noteId);
    _fetchNotes();
  }

  Color _getCategoryColor(int? categoryId) {
    if (categoryId == null) return Colors.blue.shade400;
    
    switch (categoryId % 5) {
      case 0: return Colors.blue.shade400;
      case 1: return Colors.green.shade400;
      case 2: return Colors.orange.shade400;
      case 3: return Colors.purple.shade400;
      case 4: return Colors.red.shade400;
      default: return Colors.blue.shade400;
    }
  }

  Future<void> _updateFavoriteStatus(int noteId, bool isFavorite) async {
    final dbHelper = DatabaseHelper();
    await dbHelper.updateNoteFavoriteStatus(noteId, isFavorite);
    _fetchNotes();
  }

  void _showNoteDialog(Note note) {
    showDialog(
      context: context,
      builder: (context) {
        Color categoryColor = categoryColors[note.category] ?? Colors.grey;
        return AlertDialog(
          title: Text(note.title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                note.content,
                style: TextStyle(
                  fontSize: 16,
                  color: _isDarkMode ? Colors.grey.shade300 : Colors.grey.shade800,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Category: ${note.category}',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: categoryColor,
                ),
              ),
              Text(
                'Created at: ${DateFormat('dd MMM yyyy \'at\' hh:mm a').format(DateTime.parse(note.createdAt))}',
                style: TextStyle(
                  fontSize: 12,
                  color: _isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () {
                _deleteNote(note.id!);
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      height: 60,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          // "All" category filter
          GestureDetector(
            onTap: () {
              setState(() {
                selectedCategoryId = null;
              });
              _fetchNotes();
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              margin: EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                color: selectedCategoryId == null
                    ? (_isDarkMode ? Colors.blue.shade800 : Colors.blue.shade200)
                    : (_isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                'All',
                style: TextStyle(
                  color: selectedCategoryId == null
                      ? (_isDarkMode ? Colors.white : Colors.blue.shade900)
                      : (_isDarkMode ? Colors.white : Colors.black),
                ),
              ),
            ),
          ),
          // Specific category filters
          ...categories.map((category) {
            Color color = _getCategoryColor(category.id); // Get the category color
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedCategoryId = category.id;
                });
                _fetchNotes();
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                margin: EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: selectedCategoryId == category.id
                      ? (_isDarkMode
                          ? color.withOpacity(0.8)
                          : color.withOpacity(0.3))
                      : (_isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  category.name,
                  style: TextStyle(
                    color: selectedCategoryId == category.id
                        ? (_isDarkMode ? Colors.white : color)
                        : (_isDarkMode ? Colors.white : Colors.black),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildNotesList(List<Note> notes) {
    final filteredNotes = notes.where((note) {
      return note.title.toLowerCase().contains(_searchQuery) ||
          note.content.toLowerCase().contains(_searchQuery);
    }).toList();

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      itemCount: filteredNotes.length,
      itemBuilder: (context, index) {
        return AnimatedNoteCard(
          note: filteredNotes[index],
          categoryColors: categoryColors,
          isDarkMode: _isDarkMode,
          onEdit: (updatedNote) {
            setState(() {
              notes[index] = updatedNote;
            });
            _fetchNotes();
          },
          onDelete: () {
            _deleteNote(filteredNotes[index].id!);
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: _isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: WillPopScope(
        onWillPop: () async {
          // Check if the search bar is active
          if (_searchFocusNode.hasFocus || _searchController.text.isNotEmpty) {
            setState(() {
              _searchFocusNode.unfocus(); // Dismiss the keyboard
              _searchController.clear(); // Clear the search query
              _searchQuery = ''; // Reset the search query
            });
            return false; // Prevent the app from exiting
          }
          return true; // Allow the app to exit
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text(_currentIndex == 0
                ? 'All Notes'
                : _currentIndex == 2
                    ? 'Favorites'
                    : 'Add Note'),
            actions: [
              AnimatedBuilder(
                animation: _animation,
                builder: (context, child) {
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: _animation.value * 40,
                        height: _animation.value * 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isDarkMode
                              ? Colors.white.withOpacity(0.2)
                              : Colors.black.withOpacity(0.1),
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          _isDarkMode ? Icons.dark_mode : Icons.light_mode,
                          color: _isDarkMode ? Colors.white : Colors.black,
                        ),
                        onPressed: _toggleTheme,
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
          body: Column(
            children: [
              // Search bar
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    if (_searchController.text.isNotEmpty) // Show back button if search is active
                      IconButton(
                        icon: Icon(Icons.arrow_back,
                            color: _isDarkMode ? Colors.white : Colors.black),
                        onPressed: () {
                          setState(() {
                            _searchController.clear(); // Clear the search query
                            _searchQuery = ''; // Reset the search query
                          });
                        },
                      ),
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        focusNode: _searchFocusNode, // Attach the focus node
                        onChanged: (value) {
                          setState(() {
                            _searchQuery = value.toLowerCase(); // Update the search query
                          });
                        },
                        decoration: InputDecoration(
                          hintText: 'Search notes...',
                          prefixIcon: _searchController.text.isEmpty
                              ? const Icon(Icons.search)
                              : null, // Show search icon only if no text
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: _isDarkMode
                              ? Colors.grey.shade800
                              : Colors.grey.shade200,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Category filter (if on the home page)
              if (_currentIndex == 0) _buildCategoryFilter(),

              // Notes list or other content
              if (_currentIndex == 0 || _currentIndex == 2)
                Expanded(
                  child: PageView.builder(
                    onPageChanged: (index) {
                      setState(() {
                        selectedCategoryId = index == 0 ? null : categories[index - 1].id;
                        _fetchNotes();
                      });
                    },
                    itemCount: categories.length + 1, // +1 for "All" category
                    itemBuilder: (context, index) {
                      if (_currentIndex == 2) {
                        // Favorites tab: Filter notes to show only favorites
                        final favoriteNotes =
                            notes.where((note) => note.isFavorite).toList();
                        return _buildNotesList(favoriteNotes);
                      } else if (index == 0) {
                        // "All" category
                        return _buildNotesList(notes);
                      } else {
                        // Specific category
                        final category = categories[index - 1];
                        final filteredNotes = notes
                            .where((note) => note.categoryId == category.id)
                            .toList();
                        return _buildNotesList(filteredNotes);
                      }
                    },
                  ),
                )
              else
                Expanded(
                  child: Center(
                    child: Text(
                      'Add Note Screen',
                      style: TextStyle(
                        fontSize: 24,
                        color: _isDarkMode ? Colors.white : Colors.black,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          bottomNavigationBar: CurvedNavigationBar(
            backgroundColor: const Color.fromARGB(255, 251, 251, 251),
            color: Colors.white,
            buttonBackgroundColor: const Color.fromARGB(255, 206, 206, 206),
            height: 60,
            items: <Widget>[
              Icon(
                Icons.notes,
                size: 30,
                color: _currentIndex == 0 ? Colors.black : Colors.black,
              ),
              Icon(
                Icons.add,
                size: 30,
                color: _currentIndex == 1 ? Colors.white : Colors.black,
              ),
              Icon(
                Icons.favorite,
                size: 30,
                color: _currentIndex == 2 ? Colors.redAccent : Colors.black,
              ),
            ],
            index: _currentIndex,
            onTap: (index) {
              if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddNoteScreen(
                      categories: categories,
                      isDarkMode: _isDarkMode,
                    ),
                  ),
                ).then((_) {
                  setState(() {
                    _currentIndex = 0;
                    _fetchNotes();
                  });
                });
              } else {
                setState(() {
                  _currentIndex = index;
                });
              }
            },
          ),
        ),
      ),
    );
  }
}

class AnimatedNoteCard extends StatelessWidget {
  final Note note;
  final Map<String, Color> categoryColors;
  final bool isDarkMode;
  final ValueChanged<Note> onEdit;
  final VoidCallback onDelete;

  const AnimatedNoteCard({
    super.key,
    required this.note,
    required this.categoryColors,
    required this.isDarkMode,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    Color categoryColor = categoryColors[note.category] ?? Colors.grey;
    return Container(
      margin: const EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        color: isDarkMode ? Colors.grey.shade800 : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: categoryColor.withOpacity(0.4),
            blurRadius: 16,
            spreadRadius: 4,
            offset: const Offset(4, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 6,
            decoration: BoxDecoration(
              color: categoryColor,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(12),
              ),
            ),
          ),
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: Text(note.title),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          note.content,
                          style: TextStyle(
                            fontSize: 16,
                            color: isDarkMode ? Colors.grey.shade300 : Colors.grey.shade800,
                            height: 1.4,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Category: ${note.category}',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: categoryColor,
                          ),
                        ),
                        Text(
                          'Created at: ${DateFormat('dd MMM yyyy \'at\' hh:mm a').format(DateTime.parse(note.createdAt))}',
                          style: TextStyle(
                            fontSize: 12,
                            color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Close'),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          onDelete();
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  );
                },
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    note.title,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: categoryColor,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    note.content,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      color: isDarkMode ? Colors.grey.shade300 : Colors.grey.shade800,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        DateFormat('dd MMM yyyy \'at\' hh:mm a').format(DateTime.parse(note.createdAt)),
                        style: TextStyle(
                          fontSize: 12,
                          color: isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600,
                        ),
                      ),
                      IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        icon: Icon(
                          note.isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: note.isFavorite
                              ? Colors.redAccent
                              : (isDarkMode ? Colors.grey.shade500 : Colors.grey.shade600),
                        ),
                        onPressed: () async {
                          // Toggle the favorite status
                          final updatedFavoriteStatus = !note.isFavorite;

                          // Update the favorite status in the database
                          final dbHelper = DatabaseHelper();
                          await dbHelper.updateNoteFavoriteStatus(note.id!, updatedFavoriteStatus);

                          // Refresh the notes list
                          onEdit(note.copyWith(isFavorite: updatedFavoriteStatus));
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}