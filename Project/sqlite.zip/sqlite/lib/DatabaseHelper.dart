import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'Note.dart';
import 'Category.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  Future<Database> get db async {
    _database ??= await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    String databasePath = await getDatabasesPath();
    String path = join(databasePath, 'notes.db');

    return await openDatabase(
      path,
      version: 2, // Increment the version to trigger onUpgrade
      onCreate: (db, version) async {
        // Create notes table
        await db.execute('''
          CREATE TABLE notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            content TEXT,
            categoryId INTEGER,
            createdAt TEXT,
            updatedAt TEXT,
            isFavorite INTEGER DEFAULT 0, -- Add isFavorite column with default value
            FOREIGN KEY (categoryId) REFERENCES categories (id)
          )
        ''');

        // Create categories table
        await db.execute('''
          CREATE TABLE categories(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          // Check if the 'isFavorite' column exists
          final tableInfo = await db.rawQuery("PRAGMA table_info(notes)");
          final columnExists = tableInfo.any((column) => column['name'] == 'isFavorite');

          if (!columnExists) {
            
            await db.execute('ALTER TABLE notes ADD COLUMN isFavorite INTEGER DEFAULT 0');
          }
        }
      },
    );
  }

 
  Future<int> insertNote(Note note) async {
    Database db = await this.db;
    int result = await db.insert('notes', note.toMap());
    print('Inserted Note ID: $result'); // Debugging
    return result;
  }

  Future<List<Map<String, dynamic>>> getNotes({int? categoryId}) async {
    Database db = await this.db;
    if (categoryId != null) {
      return await db.query(
        'notes',
        where: 'categoryId = ?',
        whereArgs: [categoryId],
      );
    }
    return await db.query('notes');
  }

  Future<int> updateNote(Note note) async {
    Database db = await this.db;
    return await db.update(
      'notes',
      note.toMap(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<int> deleteNote(int id) async {
    Database db = await this.db;
    return await db.delete(
      'notes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> updateNoteFavoriteStatus(int id, bool isFavorite) async {
    final db = _database!;
    await db.update(
      'notes',
      {'isFavorite': isFavorite ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // CRUD operations for Categories
  Future<int> insertCategory(Category category) async {
    Database db = await this.db;
    return await db.insert('categories', category.toMap());
  }

  Future<List<Map<String, dynamic>>> getCategories() async {
    Database db = await this.db;
    return await db.query('categories');
  }

  Future<int> updateCategory(Category category) async {
    Database db = await this.db;
    return await db.update(
      'categories',
      category.toMap(),
      where: 'id = ?',
      whereArgs: [category.id],
    );
  }

  Future<int> deleteCategory(int id) async {
    Database db = await this.db;
    return await db.delete(
      'categories',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}


