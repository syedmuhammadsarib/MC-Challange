import 'package:flutter/material.dart';
import 'DatabaseHelper.dart';
import 'Note.dart';
import 'Category.dart';

class AddNoteScreen extends StatefulWidget {
  final List<Category> categories;
  final bool isDarkMode;

  const AddNoteScreen({
    super.key, 
    required this.categories,
    required this.isDarkMode,
  });

  @override
  _AddNoteScreenState createState() => _AddNoteScreenState();
}

class _AddNoteScreenState extends State<AddNoteScreen> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  int? _selectedCategoryId;
  final List<Category> _categories = [];

  @override
  void initState() {
    super.initState();
    _initializeCategories();
  }

  void _initializeCategories() {
    _categories.addAll(widget.categories);
    if (_categories.isEmpty) {
      _categories.addAll([
        Category(id: 1, name: 'Work'),
        Category(id: 2, name: 'Personal'),
        Category(id: 3, name: 'Ideas'),
      ]);
    }
  }

  Future<void> _addNewCategory() async {
    final categoryController = TextEditingController();
    await showDialog(
      context: context,
      builder: (context) {
        return Theme(
          data: Theme.of(context).copyWith(
            dialogBackgroundColor: widget.isDarkMode 
                ? Colors.grey.shade900 
                : Colors.white,
          ),
          child: AlertDialog(
            title: Text(
              'Add New Category',
              style: TextStyle(
                color: widget.isDarkMode ? Colors.white : Colors.black,
              ),
            ),
            content: TextFormField(
              controller: categoryController,
              style: TextStyle(
                color: widget.isDarkMode ? Colors.white : Colors.black,
              ),
              decoration: InputDecoration(
                labelText: 'Category Name',
                labelStyle: TextStyle(
                  color: widget.isDarkMode ? Colors.grey.shade400 : Colors.grey,
                ),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color: widget.isDarkMode 
                        ? Colors.grey.shade700 
                        : Colors.grey.shade300,
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(
                  'Cancel',
                  style: TextStyle(
                    color: widget.isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: widget.isDarkMode 
                      ? Colors.blue.shade800 
                      : Colors.blue,
                ),
                onPressed: () {
                  if (categoryController.text.isNotEmpty) {
                    setState(() {
                      final newCategory = Category(
                        id: _categories.length + 1,
                        name: categoryController.text,
                      );
                      _categories.add(newCategory);
                    });
                    Navigator.of(context).pop();
                  }
                },
                child: const Text('Add'),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _saveNote() async {
    if (_titleController.text.isNotEmpty && _contentController.text.isNotEmpty) {
      final dbHelper = DatabaseHelper();
      Note newNote = Note(
        title: _titleController.text,
        content: _contentController.text,
        categoryId: _selectedCategoryId,
        createdAt: DateTime.now().toIso8601String(),
        updatedAt: DateTime.now().toIso8601String(),
      );
      await dbHelper.insertNote(newNote);

      // Show a SnackBar after saving the note
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Note added successfully!'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );

      Navigator.of(context).pop(); // Close the Add Note screen
    } else {
      // Show a SnackBar if the title or content is empty
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please fill in all fields!'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = widget.isDarkMode ? ThemeData.dark() : ThemeData.light();
    
    return Theme(
      data: theme,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Add Note'),
          backgroundColor: widget.isDarkMode 
              ? Colors.grey.shade900 
              : Theme.of(context).appBarTheme.backgroundColor,
          iconTheme: IconThemeData(
            color: widget.isDarkMode ? Colors.white : Colors.black,
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Title',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: widget.isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                        ? Colors.grey.shade800 
                        : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: widget.isDarkMode 
                          ? Colors.grey.shade700 
                          : Colors.grey.shade300,
                    ),
                  ),
                  child: TextFormField(
                    controller: _titleController,
                    style: TextStyle(
                      color: widget.isDarkMode ? Colors.white : Colors.black,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Enter note title',
                      hintStyle: TextStyle(
                        color: widget.isDarkMode 
                            ? Colors.grey.shade500 
                            : Colors.grey,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, 
                        vertical: 8,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Description',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: widget.isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                        ? Colors.grey.shade800 
                        : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: widget.isDarkMode 
                          ? Colors.grey.shade700 
                          : Colors.grey.shade300,
                    ),
                  ),
                  child: TextFormField(
                    controller: _contentController,
                    style: TextStyle(
                      color: widget.isDarkMode ? Colors.white : Colors.black,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Enter note description',
                      hintStyle: TextStyle(
                        color: widget.isDarkMode 
                            ? Colors.grey.shade500 
                            : Colors.grey,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, 
                        vertical: 8,
                      ),
                    ),
                    maxLines: 5,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Category',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: widget.isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: widget.isDarkMode 
                        ? Colors.grey.shade800 
                        : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: widget.isDarkMode 
                          ? Colors.grey.shade700 
                          : Colors.grey.shade300,
                    ),
                  ),
                  child: DropdownButtonFormField<int>(
                    value: _selectedCategoryId,
                    dropdownColor: widget.isDarkMode 
                        ? Colors.grey.shade800 
                        : Colors.white,
                    style: TextStyle(
                      color: widget.isDarkMode ? Colors.white : Colors.black,
                    ),
                    items: _categories
                        .map((category) => DropdownMenuItem(
                              value: category.id,
                              child: Text(
                                category.name,
                                style: TextStyle(
                                  color: widget.isDarkMode 
                                      ? Colors.white 
                                      : Colors.black,
                                ),
                              ),
                            ))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedCategoryId = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Select a category',
                      hintStyle: TextStyle(
                        color: widget.isDarkMode 
                            ? Colors.grey.shade500 
                            : Colors.grey,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, 
                        vertical: 8,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton.icon(
                  onPressed: _addNewCategory,
                  icon: Icon(
                    Icons.add,
                    color: widget.isDarkMode ? Colors.blue.shade300 : Colors.blue,
                  ),
                  label: Text(
                    'Add New Category',
                    style: TextStyle(
                      color: widget.isDarkMode ? Colors.blue.shade300 : Colors.blue,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveNote,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: widget.isDarkMode 
                          ? Colors.blue.shade800 
                          : Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Save Note',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}